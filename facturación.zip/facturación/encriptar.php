<?php
echo password_hash("carro", PASSWORD_DEFAULT);
echo password_hash("clasicos", PASSWORD_DEFAULT);

?>
